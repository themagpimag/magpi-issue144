# PDF search, with output sent to text file
import os, PyPDF2

def process_directory(path):
    for dir_or_file in os.listdir(path):
        path_plus_dir_or_file = os.path.join(path, dir_or_file)
        if os.path.isdir(path_plus_dir_or_file):
            print("\nProcessing subfolder:", dir_or_file)
            process_directory(path_plus_dir_or_file)
        elif dir_or_file.endswith('.pdf'):
            print("* Searching PDF:", dir_or_file)
            search_in_pdf(path_plus_dir_or_file)

def search_in_pdf(pdf_file):
    opened_file = open(pdf_file, 'rb')
    magazine_content = PyPDF2.PdfReader(opened_file)
    for page_number, magazine_page in enumerate(magazine_content.pages):
        page_text = magazine_page.extract_text()
        if search_string.lower() in page_text.lower():
            with open("output.txt", "a") as output_file:
                print("\n\n", file=output_file)
                print("#" * 40, file=output_file)
                print(f"Text found in {pdf_file} on page {page_number + 1}", file=output_file)
                print("#" * 40, file=output_file)
                print(page_text[0:200], "\n...\n", file=output_file)
                position_in_text = page_text.lower().rfind(search_string.lower())
                print(page_text[max(0, position_in_text - 450) :
                      min(position_in_text + 450, len(page_text))
                      ], file=output_file)

search_string = input(f"What term would you like to search for in the PDFs? ")
with open("output.txt", "w") as output_file:
    print(f"Ok! Searching for {search_string}", file=output_file)
process_directory("MagPi") # Change to your folder name