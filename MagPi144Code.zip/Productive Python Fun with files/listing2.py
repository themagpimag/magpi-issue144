# Download web pages into a docx file
import requests, sys
from bs4 import BeautifulSoup 
from docx import Document

print("Paste in the URLs (Ctrl-D to end input): ")
urls = sys.stdin.readlines()
urls = [url.strip() for url in urls]
filename = "output.docx"
doc = Document()

for source_number, url in enumerate(urls):
    print(f"Fetching {url}")
    response = requests.get(url)
    content = response.content
    soup = BeautifulSoup(content, "html.parser")
    for remove_me in soup.find_all(["nav", "footer"]):
        remove_me.extract()
        
    doc.add_heading(f"{source_number + 1} - {url}", 1)
    title = soup.title.string
    doc.add_heading(f"{source_number + 1} - {title}", 0)
    for part in soup.find_all(["p", "h1", "h2", "h3", "h4", "h5", "h6", "table", "li", "blockquote"]):
        if part.name in ["h1", "h2", "h3"]:
            doc.add_heading(part.text, 2)
        elif part.name == "li":
            doc.add_paragraph(part.text, style="List Bullet")
        elif part.text:
            doc.add_paragraph(part.text)
    doc.add_page_break()
doc.save(filename)
print(f"Saved as {filename}")