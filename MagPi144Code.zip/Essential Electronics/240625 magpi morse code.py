from gpiozero import LED
from time import sleep

led1 = LED(14)

def blink(flash_duration):
    led1.on()
    sleep(flash_duration)
    led1.off()
    sleep(0.5)
        
def flash_message(message):
    for symbol in message:
        if symbol == ".":
            blink(0.5)
        if symbol == "-":
            blink(1.5)
        if symbol == " ":
            sleep(1.5)

flash_message(".... . .-.. .-.. ---")